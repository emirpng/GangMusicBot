<h2 align="centre">Telegram Sohbet Mp3 Oynatıcı 🎵</h2>

### Güncellendi aktif.... 😇
<p align="center">
  <img src="https://telegra.ph/file/a4fa687ed647cfef52402.jpg">
</p> 

<h3>Sürümler 📮</h3>

- pyrogram Set according to your request

<h3>Yeni Eklenen 💡</h3>

- Bazı omutların açıklamasını otomatik silme. 
- atla - durdur - devam 🤔
- sohbet ve Kullanıcı (id) bilgileri çıkartma bilgisi eklendi. 

### Komutlar Genel 🍭
- `/play` - şarkı çalmak için youtube url'sine veya şarkı dosyasına yanıt verme
- `/play` - istediğiniz şarkıyı çal
- `/bul` - istediğiniz şarkıları hızlı bir şekilde indirin 
- `/ara` - youtube'da ayrıntıları içeren videoları arama

#### Yalnızca yöneticiler 
- `/ver` - üyeler için extra yetki 
- `/al` - üyeler için verilen yetki alınır (Herkes için olan komutları kullanır) 
- `/pause` - şarkı çalmayı duraklatma 
- `/resume` - şarkı çalmaya devam et 
- `/skip` - sonraki şarkıyı çal 
- `/end` - müzik çalmayı durdurma
- `/reload` - Yönetici listesini günceller
#### Grubunuza Almak için.. 
- `/asistan` - Müzik asistanı  grubunuza katılır. 
- `/ayril` - Müzik asistanı grubunuzu terk eder. 

<h4>🔺 Herokuya Dağıt 🔻</h4>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/emirpng/EfsaneMusic)


<h4>🔺 Okteto ile Kurulum 🔻</h4> 

<p align="center"><a href="https://cloud.okteto.com/deploy?repository=https://github.com/emirpng/EfsaneMusic"><img src="https://img.shields.io/badge/Deploy%20To%20Okteto-informational?style=for-the-badge&logo=Okteto" width="200" height="35.45"/></a></p>

- Bu botu barındırmanın ikinci en kolay yolu, Okteto Cloud'da Dağıt. 

- Hatalar giderildi. Halen dimdik çalışmakta olan sade bir yazılım Müzik botudur. 

- Okteto ile value şeklinde appjson 👉 Bilgilerini doldurun.. Otomatik kurulum yapar. 
